using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.SocialPlatforms.Impl;

public class frutis : MonoBehaviour
{
    public worm worm;
    public knif knife;
    public knif knife1;
    public knif axe;
    public bool canmove=false;
    public bool chosen=false;
    public bool clicked=false;
    public float speed;
    AudioSource audioSource;
    public TextMeshProUGUI scoretext;
    public GameObject image;
    public player player;
    public int lastscore;
    void Update()
    {
        if (lastscore + 35 == player.Score)
        {
            lastscore = player.Score;
            speed = (float)(speed + 0.01);
        }
        if (chosen == true && transform.position.y > 5.50f)
        {
            player.checkheal();
            float x = Random.Range(0.0f, 1f);
            StartCoroutine("randomrespawntimer");
            ResetPostion();
            player.heal--;
        }
        if (chosen ==false&& transform.position.y > 5.50f)
        {
            float x = Random.Range(0.0f, 1f);
            StartCoroutine("randomrespawntimer");
            ResetPostion();
        }
        if (chosen == false && clicked ==true)
        {
            float x = Random.Range(0.0f, 1f);
            player.checkheal();
            player.heal--;
            clicked = false;
        }

    }
    private void Awake()
    {
        audioSource = GetComponent<AudioSource>();
        ResetPostion();
     
    }
    private void FixedUpdate()
    {
        if (canmove==true)
        {
            transform.Translate(0, speed, 0);
        }
    }
    public void OnMouseDown()
    {
        audioSource.Play();
        clicked = true; 
    }
    public void ResetPostion()
    {
       
            float x = Random.Range(-2.41f, 2.41f);
            transform.position = new Vector3(x, -6.800f, 0);
       

    }
   /* private void OnCollisionEnter2D(Collision2D collision)
    {
        if ((collision.gameObject.tag == "knife" || collision.gameObject.tag== "worm") && chosen == true)
        {
            player.checkheal();
            player.heal--;
            knife.ResetPostion();
        }
        if (collision.gameObject.tag == "axe" && chosen == true)
        {
            player.heal = 1;
            player.checkheal();
           
        }
        if (collision.gameObject.tag == "axe" && chosen == false)
        {
            ResetPostion();

        }
        if (collision.gameObject.tag =="knife"&&chosen==false)
        {
            ResetPostion();
        }
    }*/
    private void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.gameObject.tag == "knife"  && chosen == true)
        {
            player.checkheal();
            player.heal--;
            knife.ResetPostion();
        }
        if (collision.gameObject.tag == "knife1" && chosen == true)
        {
            player.checkheal();
            player.heal--;
            knife1.ResetPostion();
        }

        if (collision.gameObject.tag == "axe" && chosen == true)
        {
            player.heal = 1;
            player.checkheal();

        }
        if (collision.gameObject.tag == "axe" && chosen == false)
        {
            ResetPostion();

        }
        if (collision.gameObject.tag == "knife" || collision.gameObject.tag == "knife1" && chosen == false)
        {
            ResetPostion();
        }
        if (collision.gameObject.tag == "worm" && chosen == true)
        {
            player.checkheal();
            player.heal--;
            worm.restpostion();
        }
    }
    private IEnumerator randomrespawntimer()
    {
        yield return new WaitForSeconds(4);



    }

}
