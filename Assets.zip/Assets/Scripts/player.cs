using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;

public class player : MonoBehaviour
{
    public bool open = false;
    public GameObject btn0;
    public GameObject btn150;
    public static int Score = 0;
    public int changefrut = 0;
    public int heal = 2;
    public GameObject dying, dying1, dying2;
    public TextMeshProUGUI scoretext;
    public AudioSource audioSource;
    public frutis apple;
    public frutis banana;
    public frutis lemon;
    public frutis orange;
    public frutis pear;
    public frutis strawberry;
    public frutis chosenfrut = new frutis();
    public GameObject Settingbutton;
    public frutis[] frutmix = new frutis[6];
    public int i = 0;
    public bool Canstart = true;

    private void OnMouseDown()
    {
        if (Canstart == true)
        {
            takechosenfrutfirst();
            apple.canmove = true;
            banana.canmove = true;
            lemon.canmove = true;
            orange.canmove = true;
            pear.canmove = true;
            strawberry.canmove = true;
            open = true;
            Settingbutton.SetActive(false);
            transform.position = new Vector3(-6.48f, 0.13f, 0);
        }
    }
    private void Awake()
    {
        audioSource = GetComponent<AudioSource>();
        if (Score < 150)
        {
            score0();
            changefrut = 0;
        }
        if (Score >= 150)
        {
            changefrut = 150;
            score150();
        }
    }

    void Update()
    {
        if (changefrut + 30 == Score)
        {
            changefrut += 30;
            chosenfrut.image.SetActive(false);
            chosenfrut.chosen = false;
            takechosenfrut();
        }

        if (chosenfrut.clicked == true)
        {
            Score++;
            chosenfrut.ResetPostion();
            scoretext.text = Score.ToString();
            chosenfrut.clicked = false;
        }
    }
    public void checkheal()
    {

        if (heal == 2)
        {
            audioSource.Play();
            dying.SetActive(false);
            dying1.SetActive(true);
            return;
        }
        if (heal == 1)
        {
            audioSource.Play();
            dying.SetActive(false);
            dying1.SetActive(false);
            dying2.SetActive(true);
            StartCoroutine("endgame");
        }
    }
    public void takechosenfrutfirst()
    {

        frutis chosen = new frutis();
        frutmix = new frutis[] { apple, banana, lemon, orange, pear, strawberry };
        int index = i;
        while (index == i) {
            index = Random.Range(0, 6);
            chosen = frutmix[index];
        }
        i = index;
        chosenfrut = chosen;
        chosenfrut.chosen = true;
        chosenfrut.image.SetActive(true);
    }

    public void takechosenfrut()
    {
        bool first = true;
        frutmix = new frutis[] { apple, banana, lemon, orange, pear, strawberry };
        frutis lowestfrut = apple;
        int c = 0;
        for (int j = 0; j < frutmix.Length; j++)
        {
            if (i == j)
            {
                continue;
            }
            if (first == true)
            {
                lowestfrut = frutmix[j];
                first = false;
            }
            if (frutmix[j].transform.position.y < lowestfrut.transform.position.y)
            {
                lowestfrut = frutmix[j];
                c = j;
            }
        }
        i = c;
        chosenfrut = lowestfrut;
        chosenfrut.chosen = true;
        chosenfrut.image.SetActive(true);
    }

    public void score150()
    {
        Score = 150;
        scoretext.text = "150"; 
        btn150.SetActive(false);
        btn0.SetActive(true);
    }
    public void score0()
    {
        Score = 0;
        scoretext.text = "0";
        btn0.SetActive(false);
        btn150.SetActive(true);
    }
    private IEnumerator endgame()
    {
        yield return new WaitForSeconds(1);
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
      
    }
}
       