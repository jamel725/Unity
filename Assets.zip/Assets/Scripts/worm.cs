using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;

public class worm : MonoBehaviour
{
    public player player;
    public frutis apple;
    public frutis banana;
    public frutis lemon;
    public frutis orange;
    public frutis pear;
    public frutis strawberry;
    public frutis chosenfrut;
    public frutis[] frutmix = new frutis[6];
    public GameObject image;
    public float lastx, lasty;
    public float xplace, yplace;
    public int wormrespawn;
    public int i;
    public float speed;
    public bool canmove = false;

  
  

    private void OnMouseDown()
    {
   
            restpostion();

        
    }
    void Awake()
    {
       
        
            lastx = transform.position.x;
            lasty = transform.position.y;
     
        frutmix = new frutis[] { apple, banana, lemon, orange, pear, strawberry };
        wormrespawn = 100;
       
    }
    void Update()
    {
       
        chosenfrut = player.chosenfrut;
        if(this.transform.position.y <= -5.50f)
        {
            restpostion();
        }
        if (wormrespawn <= player.Score)
        {
            canmove = true;
            wormrespawn = wormrespawn + 5;
            xplace = chosenfrut.transform.position.x;
            yplace = chosenfrut.transform.position.y;
            image.transform.position = new Vector3(xplace, yplace + 9f, 0);
            StartCoroutine(worms());

        }

    }
    private void FixedUpdate()
    {
        if (player.Score >= 100 && canmove==true)
        {
            transform.Translate(0, speed, 0);
        }
     
    }


    private IEnumerator worms()
    {

        yield return new WaitForSeconds(1);
        this.transform.position = new Vector3(xplace, yplace + 9f, 0);


    }
    public void restpostion()
    {
        this.transform.position = new Vector3(lastx, lasty, 0);
        image.transform.position = new Vector3(lastx, lasty, 0);
        canmove = false;    
    }
  

}

