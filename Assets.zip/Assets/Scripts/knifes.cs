using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UIElements;

public class knif : MonoBehaviour
{
    public float speed;
    public player player;
    public frutis chosen;
    public float xposition;
    public bool isdown=false;
    public bool ishit = false;
    public bool canmove=false;
    public int axemove = 97;
    public float axexposition, axeyposition;

    public void Awake()
    {
        axemove = 97;
        axexposition = this.transform.position.x;
        axeyposition = this.transform.position.y;

    }
    private void FixedUpdate()
    {

        if (player.open==true&&canmove==true)
        {
            this.transform.Translate(0, speed, 0);
        }
        
    }
    void Update()
    {
        if (this.tag == "knife" && player.Score > 20)
        {
            canmove = true;
        }
        if (this.tag == "knife1" && player.Score > 50)
        {
            canmove = true;
        }
        if (this.tag == "axe"  &&  player.Score>99)
        {
            if (150 == player.Score)
            {
                axemove = 150;
            }
            if (axemove + 5 == player.Score)
            {
                axemove = player.Score;
                dropit();
            }
           
        }
      
      

        if (isdown == false && ishit == true || this.transform.position.y < -0.25)
        {
            isdown = true;
        }
        if (isdown == true)
        {
            ResetPostion();
            isdown = false;
        }
       
    }

     /*private void OnCollisionEnter2D(Collision2D collision)
     {
        
             if (collision.gameObject.tag == "chosen")
             {
                 if (this.tag == "knife" || this.tag == "knife1")
                 {
                     player.checkheal();
                     ishit = true;
                     player.heal--;
                 }
                 if (this.tag == "axe")
                 {
                     player.checkheal();
                     ishit = true;
                     player.heal = 1;
                 }
             }
             if (collision.gameObject.tag == "frut")
             {
                 ResetPostion();
             }
       
}*/

   public void ResetPostion()
    {
        if (this.tag == "axe")
        {
            canmove = false;
            this.transform.position = new Vector3(axexposition, axeyposition, 0);

        }
        else
        {
            xposition = Random.Range(-2.41f, 2.41f);
            transform.position = new Vector3(xposition, 5.644f, 0);
        }
     }
    public void dropit()
    {
        if (this.tag == "axe")
        {
            float x = Random.Range(-2.41f, 2.41f);
            this.transform.position = new Vector3(x, 5.644f, 0);
            canmove = true;

        }
        else
        {
            xposition = Random.Range(-2.41f, 2.41f);
            transform.position = new Vector3(xposition, 5.644f, 0);
        }
    }
}
