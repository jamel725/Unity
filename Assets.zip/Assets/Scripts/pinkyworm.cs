using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;

public class pinkyworm : MonoBehaviour
{
  public player player;
  public float speed;
  public float xposition, yposition;
  public bool canmove=false;
  public int startmove;
  

    public void Awake()
    {
        xposition = this.transform.position.x;
        yposition = this.transform.position.y;
        startmove = 143;
    }
    public void OnMouseDown()
    {
        restposition();

    }
    private void FixedUpdate()
    {
        if (canmove == true)
        {
            transform.Translate(0, speed, 0);
        }
    }

    void Update()
    {
        if (this.transform.position.y <= -5.50f)
        {
            restposition();
            player.checkheal();
            player.heal--;
        }

        if (startmove + 8==player.Score)
        {
         startmove = player.Score;
         dropeit();
        }
        

        
    }

    private void dropeit()
    {
        float x = Random.Range(-2.41f, 2.41f);
        this.transform.position = new Vector3(x, 5.644f, 0);
        canmove = true;
    }

    void restposition()
    {
        canmove = false;
        this.transform.position = new Vector3(xposition, yposition, 0);
    }
}

