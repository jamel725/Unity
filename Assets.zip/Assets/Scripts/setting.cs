using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;

public class setting : MonoBehaviour
{
    public player maingame;
    public Camera maincamera;
    public GameObject bdark;
    public GameObject bwhite;
    private static bool iswhite=true;
    public GameObject Gamepanel;
    public GameObject Settingpanel;
    public GameObject explainpanel;
    public GameObject btn0;
    public GameObject btn150;
    public GameObject scoretext;
    private void Awake()
    {
        if (iswhite == false)
        {
            maincamera.backgroundColor = Color.gray;
        }
        
    }
    public void darkmodechanger()
    {
        maincamera.backgroundColor = Color.gray;
        bwhite.SetActive(true);
        bdark.SetActive(false);
        iswhite = false;
    }
    public void whitemodechanger()
    {
       
        maincamera.backgroundColor = Color.white;
        bdark.SetActive(true);
        bwhite.SetActive(false);
        iswhite = true;
    }
    public void backTogame()
    {

        Settingpanel.SetActive(false);
        maingame.Canstart = true;
    }
    public void goTosetting()
    {
        maingame.Canstart = false;
        if (maincamera.backgroundColor == Color.white)
        {
            Gamepanel.SetActive(true);
            bdark.SetActive(true);
            bwhite.SetActive(false);
        }
        if (maincamera.backgroundColor == Color.gray)
        {
            Gamepanel.SetActive(true);
            bdark.SetActive(false);
            bwhite.SetActive(true);
        }

    }
    public void backTosetting()
    {
        Settingpanel.SetActive(true);
        explainpanel.SetActive(false);
    }
    public void GoToexplain()
    {
        explainpanel.SetActive(true);
        Settingpanel.SetActive(false);
    }
}